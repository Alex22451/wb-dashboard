// ─── Shared WB Mapping Module ──────────────────────────────────────────
// Extracted from wb-compare/route.ts for reuse across all WB data endpoints

// ─── WB Subject → Excel Type Mapping ──────────────────────────────────
export const SUBJECT_TO_EXCEL_TYPES: Array<{ subject: string; types: string[] }> = [
  { subject: 'Подушки внутренние', types: ['подушка внутренняя', 'подушка декоративная'] },
  { subject: 'Подушки декоративные', types: ['подушка декоративная', 'подушка внутренняя'] },
  { subject: 'Подушки', types: ['подушка декоративная', 'подушка внутренняя'] },
  { subject: 'Наволочки декоративные', types: ['наволочка декоративная', 'наволочки декоративные', 'наволочки под сублимацию'] },
  { subject: 'Наволочки', types: ['наволочка декоративная', 'наволочки декоративные', 'наволочки под сублимацию'] },
  { subject: 'Карнавальные маски', types: ['маски'] },
  { subject: 'Чехлы для бутылей', types: ['чехлы для бутылей'] },
  { subject: 'Чехлы для чемоданов', types: ['чехлы на чемодан'] },
  { subject: 'Фартуки кухонные', types: ['фартуки'] },
  { subject: 'Флаги', types: ['флаги'] },
  { subject: 'Коврики пляжные', types: ['пляжные коврики'] },
  { subject: 'Декор для одежды', types: ['шевроны'] },
  { subject: 'Мешки для обуви', types: ['мешки для обуви', 'чехол для обуви', 'шоппер для обуви'] },
  { subject: 'Коврики для мыши', types: ['коврики для мыши'] },
  { subject: 'Колышки и скобы садовые', types: ['колышки для пляжных ковриков'] },
  { subject: 'Колышки для палаток', types: ['колышки для пляжных ковриков'] },
  { subject: 'Брелоки', types: ['ремувки', 'брелоки'] },
  { subject: 'Гобелены', types: ['гобелен', 'фотофоны'] },
  { subject: 'Фотофоны', types: ['фотофоны', 'гобелен'] },
  { subject: 'Мочалки', types: [] },
  { subject: 'Коврики для намаза', types: ['коврики для намаза'] },
  { subject: 'Сумки пляжные', types: ['сумки пляжные'] },
  { subject: 'Сумки хозяйственные', types: ['сумки хозяйственные (шоппер)'] },
  { subject: 'Сумки-шопперы', types: ['сумки хозяйственные (шоппер)', 'шоппер для обуви'] },
  { subject: 'Сумки', types: ['сумки пляжные', 'сумки хозяйственные (шоппер)', 'шоппер для обуви'] },
  { subject: 'Скатерти', types: ['скатерти', 'дорожки'] },
  { subject: 'Салфетки', types: ['салфетки', 'салфетки с вышивкой'] },
  { subject: 'Дорожки кухонные', types: ['дорожки'] },
  { subject: 'Наборы для создания слепков', types: ['набор'] },
  { subject: 'Наборы для рисования', types: ['набор'] },
  { subject: 'Стаканы', types: [] },
  { subject: 'Пледы', types: ['плед', 'плед флисовый'] },
  { subject: 'Мягкие игрушки', types: ['мягкие игрушки', 'игрушки антистресс'] },
  { subject: 'Игрушки антистресс', types: ['игрушки антистресс', 'мягкие игрушки'] },
  { subject: 'Кольца для салфеток', types: ['кольца для салфеток'] },
  { subject: 'Ткань', types: ['ткань'] },
  { subject: 'Ткани для рукоделия', types: ['ткань'] },
]

// WB subject categories to exclude entirely
export const EXCLUDED_WB_SUBJECTS: string[] = [
  'Картины по номерам',
  'Картины',
  'Алмазная мозаика',
  'Конструкторы',
  'Костюмы маскировочные',
  'Термокомплекты',
  'Анальные пробки',
  'Помпы для воды',
  'Вибраторы',
  'Портупеи эротик',
  'Портупеи',
  'Ошейники',
  'Маски эротик',
  'Рюкзаки',
  'Дождевики',
]

// ─── Article/Brand Keyword Overrides ──────────────────────────────────
interface ArticleOverride {
  subjectContains: string
  articlePattern: RegExp
  brandPattern?: RegExp
  exactSubject?: boolean
  excelType: string
  priority: number
}

export const ARTICLE_OVERRIDES: ArticleOverride[] = [
  { subjectContains: 'декор для одежды', articlePattern: /шеврон/i, excelType: 'шевроны', priority: 110 },
  { subjectContains: 'декор для одежды', articlePattern: /./i, excelType: 'шевроны', priority: 30 },

  { subjectContains: 'брелоки', articlePattern: /./i, brandPattern: /ремувикс|ремув/i, excelType: 'ремувки', priority: 120 },
  { subjectContains: 'брелоки', articlePattern: /./i, excelType: 'ремувки', priority: 30 },

  { subjectContains: 'мешки для обуви', articlePattern: /чехол/i, excelType: 'чехол для обуви', priority: 110 },
  { subjectContains: 'мешки для обуви', articlePattern: /шоппер.*обув|обув.*шоппер/i, excelType: 'шоппер для обуви', priority: 111 },
  { subjectContains: 'мешки для обуви', articlePattern: /шоппер/i, excelType: 'шоппер для обуви', priority: 100 },
  { subjectContains: 'мешки для обуви', articlePattern: /мешок/i, excelType: 'мешки для обуви', priority: 105 },
  { subjectContains: 'мешки для обуви', articlePattern: /./i, excelType: 'мешки для обуви', priority: 20 },

  { subjectContains: 'салфетки', articlePattern: /салфеткавышивк|вышивк/i, excelType: 'салфетки с вышивкой', priority: 110, exactSubject: true },
  { subjectContains: 'салфетки', articlePattern: /салфеткавкорзин|вкорзин/i, excelType: 'салфетки', priority: 105, exactSubject: true },
  { subjectContains: 'салфетки', articlePattern: /./i, excelType: 'салфетки', priority: 20, exactSubject: true },

  { subjectContains: 'сумки-шопперы', articlePattern: /обувь/i, excelType: 'шоппер для обуви', priority: 110 },
  { subjectContains: 'сумки-шопперы', articlePattern: /шоппер.*обув|обув.*шоппер/i, excelType: 'шоппер для обуви', priority: 111 },
  { subjectContains: 'сумки-шопперы', articlePattern: /./i, excelType: 'сумки хозяйственные (шоппер)', priority: 20 },

  { subjectContains: 'скатерти', articlePattern: /дорожк/i, excelType: 'дорожки', priority: 110, exactSubject: true },
  { subjectContains: 'скатерти', articlePattern: /./i, excelType: 'скатерти', priority: 20, exactSubject: true },

  { subjectContains: 'сумки', articlePattern: /сумкапляж|пляжоксфорд|сумкапляжоксфорд|сумкапляждвунитк/i, excelType: 'сумки пляжные', priority: 110, exactSubject: true },
  { subjectContains: 'сумки', articlePattern: /шоппер.*обув|обув.*шоппер/i, excelType: 'шоппер для обуви', priority: 109, exactSubject: true },
  { subjectContains: 'сумки', articlePattern: /./i, excelType: 'сумки пляжные', priority: 20, exactSubject: true },

  { subjectContains: 'гобелены', articlePattern: /./i, excelType: 'гобелен', priority: 20 },
  { subjectContains: 'фотофоны', articlePattern: /гобелен/i, excelType: 'гобелен', priority: 110 },
  { subjectContains: 'фотофоны', articlePattern: /./i, excelType: 'фотофоны', priority: 20 },

  { subjectContains: 'подушки внутренние', articlePattern: /./i, excelType: 'подушка внутренняя', priority: 20 },
  { subjectContains: 'подушки декоративные', articlePattern: /внутренняя/i, excelType: 'подушка внутренняя', priority: 110 },
  { subjectContains: 'подушки декоративные', articlePattern: /./i, excelType: 'подушка декоративная', priority: 20 },

  { subjectContains: 'наволочки декоративные', articlePattern: /подсублим|сублим/i, excelType: 'наволочки под сублимацию', priority: 110 },
  { subjectContains: 'наволочки декоративные', articlePattern: /./i, excelType: 'наволочка декоративная', priority: 20 },

  { subjectContains: 'игрушки антистресс', articlePattern: /антистресс/i, excelType: 'игрушки антистресс', priority: 100 },
  { subjectContains: 'игрушки антистресс', articlePattern: /./i, excelType: 'игрушки антистресс', priority: 20 },
  { subjectContains: 'мягкие игрушки', articlePattern: /./i, excelType: 'мягкие игрушки', priority: 20 },

  { subjectContains: 'наборы для создания слепков', articlePattern: /./i, excelType: 'набор', priority: 50 },
  { subjectContains: 'наборы для рисования', articlePattern: /./i, excelType: 'набор', priority: 50 },
]

// ─── Find matching subject types ──────────────────────────────────
export function findSubjectTypes(wbSubject: string): string[] {
  const subjectLower = wbSubject.toLowerCase()

  const exactMatch = SUBJECT_TO_EXCEL_TYPES.find(e => e.subject.toLowerCase() === subjectLower)
  if (exactMatch) return exactMatch.types

  let bestMatch: string[] = []
  let bestLen = 0
  for (const entry of SUBJECT_TO_EXCEL_TYPES) {
    const entryLower = entry.subject.toLowerCase()
    if (subjectLower.includes(entryLower) || entryLower.includes(subjectLower)) {
      if (entry.subject.length > bestLen) {
        bestLen = entry.subject.length
        bestMatch = entry.types
      }
    }
  }
  return bestMatch
}

// ─── Fuzzy match helper ──────────────────────────────────────────────
export function typeKeyMatches(typeKey: string, targetType: string): boolean {
  if (typeKey === targetType) return true
  if (typeKey.includes(targetType) || targetType.includes(typeKey)) return true
  return false
}

// ─── Extract WB size from article ──────────────────────────────────
export function extractWbSize(article: string): string {
  const match = article.match(/(\d{1,3})\s*х\s*(\d{1,3})/i)
  if (match) {
    const d1 = parseInt(match[1]), d2 = parseInt(match[2])
    if (d1 >= 8 || d2 >= 8 || match[1].length >= 2 || match[2].length >= 2) {
      return `${match[1]}х${match[2]}`
    }
  }
  const matchStar = article.match(/(\d{1,3})\s*[*x]\s*(\d{1,3})/i)
  if (matchStar) {
    const d1 = parseInt(matchStar[1]), d2 = parseInt(matchStar[2])
    if (d1 >= 8 || d2 >= 8 || matchStar[1].length >= 2 || matchStar[2].length >= 2) {
      return `${matchStar[1]}х${matchStar[2]}`
    }
  }
  return ''
}

// ─── Normalize size ────────────────────────────────────────────────
export function normalizeSize(size: string): string {
  return size.replace(/[*x]/g, 'х').toLowerCase().trim()
}

// ─── Extract pack quantity ─────────────────────────────────────────
export function extractPackQty(name: string): string {
  const match = name.match(/(\d+)\s*шт/i)
  return match ? match[1] : ''
}

// ─── WB API Request with minimal retry ──────────────────────────────────
// Only retry once on 429 with a long delay — do NOT aggressively retry
export async function fetchWbApi(url: string, options: RequestInit, maxRetries = 1): Promise<Response> {
  const response = await fetch(url, options)
  if (response.status === 429 || response.status === 461) {
    if (maxRetries > 0) {
      // Wait 10 seconds and try once more
      console.log(`WB API rate limited (429), waiting 10s before single retry`)
      await new Promise(resolve => setTimeout(resolve, 10000))
      return await fetch(url, options)
    }
  }
  return response
}

// ─── Filter records to date range ──────────────────────────────────
// Only filters by date, does NOT filter isCancel or saleID (we count ALL orders)
export function filterToDateRange(records: any[], filterFrom: string, filterTo: string): any[] {
  return records.filter((o: any) => {
    const d = o.date?.substring(0, 10)
    if (!d || d < filterFrom || d > filterTo) return false
    return true
  })
}

// ─── Simplified mapping: WB order → product type name ──────────────
// Given a WB order's subject, article, and brand,
// return the mapped product type name (like "мешки для обуви", "шевроны", etc.)
export function mapWbOrderToType(subject: string, article: string, brand: string): string {
  const subjectLower = subject.toLowerCase()
  const articleNorm = article.toLowerCase().replace(/_/g, '').replace(/\s/g, '')
  const brandLower = (brand || '').toLowerCase()

  // 1. Check EXCLUDED subjects
  if (EXCLUDED_WB_SUBJECTS.some(excl => subjectLower.includes(excl.toLowerCase()))) {
    return ''
  }

  // 2. Get possible types from subject mapping
  const possibleTypes = findSubjectTypes(subject)
  if (possibleTypes.length === 0) {
    // Subject not in mapping at all - return subject itself or 'Другое'
    return subject || 'Другое'
  }

  // 3. Check article/brand keyword overrides (simplified - no Excel data needed)
  const matchingOverrides = ARTICLE_OVERRIDES
    .filter(rule => rule.exactSubject ? subjectLower === rule.subjectContains : subjectLower.includes(rule.subjectContains))
    .filter(rule => rule.articlePattern.test(articleNorm))
    .filter(rule => !rule.brandPattern || rule.brandPattern.test(brandLower))
    .sort((a, b) => b.priority - a.priority)

  if (matchingOverrides.length > 0) {
    return matchingOverrides[0].excelType
  }

  // 4. Return the first (primary) type from subject mapping
  return possibleTypes[0]
}
