import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const adSpends = await db.$queryRawUnsafe<Array<{
      entrepreneurId: number
      entrepreneurName: string
      year: number
      month: number
      budget: number | null
      actual: number | null
    }>>(`
      SELECT a.entrepreneurId, e.name as entrepreneurName, a.year, a.month, a.budget, a.actual
      FROM AdSpend a
      JOIN Entrepreneur e ON a.entrepreneurId = e.id
      WHERE a.year = 2026
      ORDER BY a.year, a.month
    `)

    const entrepreneurs = await db.$queryRawUnsafe<Array<{ id: number; name: string }>>(
      `SELECT id, name FROM Entrepreneur ORDER BY id`
    )

    // Group by entrepreneur
    const grouped: Record<number, { entrepreneur: string; budget: number; months: { month: number; actual: number }[] }> = {}
    adSpends.forEach((a) => {
      if (!grouped[a.entrepreneurId]) {
        grouped[a.entrepreneurId] = {
          entrepreneur: a.entrepreneurName,
          budget: a.budget || 0,
          months: [],
        }
      }
      if (a.actual && a.actual > 0) {
        grouped[a.entrepreneurId].months.push({ month: a.month, actual: a.actual })
      }
    })

    return NextResponse.json({ entrepreneurs, grouped })
  } catch (error) {
    console.error('Ad spend API error:', error)
    return NextResponse.json({ error: 'Failed to load ad spend data' }, { status: 500 })
  }
}
