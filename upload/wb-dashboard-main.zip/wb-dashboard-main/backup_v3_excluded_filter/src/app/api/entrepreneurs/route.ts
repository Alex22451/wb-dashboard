import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Filter entrepreneurs stats for 2026 only
    const entrepreneurs = await db.$queryRawUnsafe<Array<{
      id: number
      name: string
      wbApiKey: string | null
      totalOrders: bigint
    }>>(`
      SELECT e.id, e.name, e.wbApiKey,
        COALESCE(SUM(do_q.quantity), 0) as totalOrders
      FROM Entrepreneur e
      LEFT JOIN DailyOrder do_q ON e.id = do_q.entrepreneurId AND do_q.date >= '2026-01-01' AND do_q.date < '2027-01-01'
      GROUP BY e.id, e.name, e.wbApiKey
      ORDER BY e.id
    `)

    const result = entrepreneurs.map((e) => ({
      id: e.id,
      name: e.name,
      wbApiKey: e.wbApiKey,
      totalOrders: Number(e.totalOrders),
      hasApiKey: !!e.wbApiKey,
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Entrepreneurs API error:', error)
    return NextResponse.json({ error: 'Failed to load entrepreneurs' }, { status: 500 })
  }
}
