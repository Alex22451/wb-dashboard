import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import {
  mapWbOrderToType,
  filterToDateRange,
  EXCLUDED_WB_SUBJECTS,
} from '@/lib/wb-mapping'

// ─── In-memory cache ────────────────────────────────────────────────
// Caches WB API responses to avoid hitting the API on every request
// TTL: 5 minutes for dashboard, 2 minutes for daily, 10 minutes for monthly
interface CacheEntry {
  data: any
  timestamp: number
  ttl: number
}

const apiCache = new Map<string, CacheEntry>()

function getCacheKey(entId: number, dateFrom: string): string {
  return `${entId}:${dateFrom}`
}

function getCached(key: string): any | null {
  const entry = apiCache.get(key)
  if (!entry) return null
  if (Date.now() - entry.timestamp > entry.ttl) {
    apiCache.delete(key)
    return null
  }
  return entry.data
}

function setCache(key: string, data: any, ttlMs: number): void {
  apiCache.set(key, { data, timestamp: Date.now(), ttl: ttlMs })
  // Prune old entries
  if (apiCache.size > 50) {
    const now = Date.now()
    for (const [k, v] of apiCache) {
      if (now - v.timestamp > v.ttl) apiCache.delete(k)
    }
  }
}

const CACHE_TTL_DASHBOARD = 5 * 60 * 1000   // 5 min
const CACHE_TTL_DAILY = 2 * 60 * 1000       // 2 min
const CACHE_TTL_MONTHLY = 10 * 60 * 1000    // 10 min

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl
    const entrepreneurId = searchParams.get('entrepreneurId') || 'all'
    const section = searchParams.get('section') || '' // 'dashboard' | 'daily' | 'monthly' | '' (all)

    // Calculate date range based on section
    const mskOffset = 3 * 60 * 60 * 1000
    const nowMsk = new Date(Date.now() + mskOffset)
    let defaultDateFrom: string

    if (section === 'dashboard') {
      const twoMonthsAgo = new Date(nowMsk.getTime() - 60 * 86400000)
      defaultDateFrom = twoMonthsAgo.toISOString().split('T')[0]
    } else if (section === 'monthly') {
      const sixMonthsAgo = new Date(nowMsk.getTime() - 180 * 86400000)
      defaultDateFrom = sixMonthsAgo.toISOString().split('T')[0]
    } else if (section === 'daily') {
      const threeDaysAgo = new Date(nowMsk.getTime() - 3 * 86400000)
      defaultDateFrom = threeDaysAgo.toISOString().split('T')[0]
    } else {
      const threeMonthsAgo = new Date(nowMsk.getTime() - 90 * 86400000)
      defaultDateFrom = threeMonthsAgo.toISOString().split('T')[0]
    }

    const dateFrom = searchParams.get('dateFrom') || defaultDateFrom
    const dateTo = searchParams.get('dateTo') || new Date().toISOString().split('T')[0]

    // Get entrepreneurs with API keys
    const entResult = await db.$queryRawUnsafe<Array<{ id: number; name: string; wbApiKey: string }>>(
      `SELECT id, name, wbApiKey FROM Entrepreneur WHERE wbApiKey IS NOT NULL AND wbApiKey != ''`
    )

    let targets: Array<{ id: number; name: string; wbApiKey: string }>

    if (entrepreneurId === 'all') {
      targets = entResult
    } else {
      const entId = Number(entrepreneurId)
      targets = entResult.filter(e => e.id === entId)
    }

    if (targets.length === 0) {
      return NextResponse.json({
        dashboard: {
          totalOrders: 0, yesterdayOrders: 0, dayBeforeYesterdayOrders: 0,
          yesterdayDate: null, monthOrders: 0, prevMonthOrders: 0, latestDate: null,
          dayChange: null, monthChange: null,
          entrepreneurStats: [], productCount: 0,
        },
        daily: { dates: [], products: [], pivot: {}, dateTotals: [], productTotals: {} },
        monthly: { entrepreneurs: [], products: [], months: [], monthlyData: {}, productMonthlyData: {} },
        rateLimitErrors: [],
      })
    }

    // Determine cache TTL based on section
    const cacheTtl = section === 'dashboard' ? CACHE_TTL_DASHBOARD
      : section === 'daily' ? CACHE_TTL_DAILY
      : section === 'monthly' ? CACHE_TTL_MONTHLY
      : CACHE_TTL_DASHBOARD

    // Fetch orders for each entrepreneur SEQUENTIALLY with delays
    // Use cache to avoid repeated API calls
    const results: Array<{
      entrepreneurId: number
      entrepreneurName: string
      orders: any[]
      error?: string
    }> = []

    for (let i = 0; i < targets.length; i++) {
      const ent = targets[i]
      const cacheKey = getCacheKey(ent.id, dateFrom)

      // Check cache first
      const cached = getCached(cacheKey)
      if (cached) {
        results.push(cached)
        continue
      }

      const apiHeaders = { 'Authorization': `Bearer ${ent.wbApiKey}`, 'Content-Type': 'application/json' }

      // Delay between entrepreneurs (1s) to respect rate limits
      if (i > 0) {
        await new Promise(resolve => setTimeout(resolve, 1000))
      }

      let orders: any[] = []
      let error: string | undefined

      try {
        const ordersUrl = `https://statistics-api.wildberries.ru/api/v1/supplier/orders?dateFrom=${dateFrom}&flag=0`
        const response = await fetch(ordersUrl, { headers: apiHeaders, signal: AbortSignal.timeout(30000) })

        if (response.status === 429 || response.status === 461) {
          console.log(`WB API rate limited for ${ent.name}, skipping (429)`)
          error = 'Превышен лимит запросов (429), попробуйте позже'
        } else if (response.status === 401) {
          console.log(`WB API unauthorized for ${ent.name} (401)`)
          error = 'Неверный API ключ (401)'
        } else if (response.ok) {
          const allOrders = await response.json()
          if (Array.isArray(allOrders)) {
            orders = filterToDateRange(allOrders, dateFrom, dateTo)
          }
        } else {
          console.log(`WB API error for ${ent.name}: ${response.status}`)
          error = `Ошибка API (${response.status})`
        }
      } catch (_e) {
        console.log(`WB API network error for ${ent.name}`)
        error = 'Ошибка сети'
      }

      const result = {
        entrepreneurId: ent.id,
        entrepreneurName: ent.name,
        orders,
        error,
      }

      // Cache only successful results (with orders)
      if (!error) {
        setCache(cacheKey, result, cacheTtl)
      }

      results.push(result)
    }

    // Collect all successful results with mapped types
    const allMappedOrders: Array<{
      entrepreneurId: number
      entrepreneurName: string
      order: any
      mappedType: string
      dateStr: string
      monthStr: string
    }> = []

    for (const result of results) {
      const { entrepreneurId, entrepreneurName, orders } = result

      for (const order of orders) {
        const subject = order.subject || ''
        const article = order.supplierArticle || ''
        const brand = order.brand || ''

        // Filter out EXCLUDED subjects (Картины, Алмазная мозаика, etc.)
        // These categories should NOT be counted in analytics/statistics
        const subjectLower = subject.toLowerCase()
        if (EXCLUDED_WB_SUBJECTS.some(excl => subjectLower.includes(excl.toLowerCase()))) {
          continue
        }

        const mappedType = mapWbOrderToType(subject, article, brand)
        if (!mappedType) continue

        const dateStr = order.date?.substring(0, 10) || ''
        const monthStr = dateStr.substring(0, 7)

        allMappedOrders.push({
          entrepreneurId,
          entrepreneurName,
          order,
          mappedType,
          dateStr,
          monthStr,
        })
      }
    }

    // Collect rate limit errors for UI display
    const rateLimitErrors = results
      .filter(r => r.error)
      .map(r => ({ id: r.entrepreneurId, name: r.entrepreneurName, error: r.error }))

    // Build response based on requested section(s)
    const needDashboard = !section || section === 'dashboard'
    const needDaily = !section || section === 'daily'
    const needMonthly = !section || section === 'monthly'

    // Product types (shared across sections)
    const productTypes = [...new Set(allMappedOrders.map(o => o.mappedType))]

    const response: Record<string, any> = { rateLimitErrors }

    // ─── Build Dashboard ───
    if (needDashboard) {
      // All dates in Moscow timezone (UTC+3)
      const mskOffset = 3 * 3600000
      const mskNow = new Date(Date.now() + mskOffset)
      const todayMsk = mskNow.toISOString().split('T')[0]
      const yesterdayMsk = new Date(mskNow.getTime() - 86400000).toISOString().split('T')[0]
      const dayBeforeMsk = new Date(mskNow.getTime() - 2 * 86400000).toISOString().split('T')[0]
      const currentMonth = todayMsk.substring(0, 7)
      // Previous month in Moscow timezone
      const prevMonthDate = new Date(mskNow)
      prevMonthDate.setMonth(prevMonthDate.getMonth() - 1)
      const prevMonth = prevMonthDate.toISOString().substring(0, 7)

      const totalOrders = allMappedOrders.length
      const yesterdayOrders = allMappedOrders.filter(o => o.dateStr === yesterdayMsk).length
      const dayBeforeYesterdayOrders = allMappedOrders.filter(o => o.dateStr === dayBeforeMsk).length
      const monthOrders = allMappedOrders.filter(o => o.monthStr === currentMonth).length
      const prevMonthOrders = allMappedOrders.filter(o => o.monthStr === prevMonth).length

      const allDates = [...new Set(allMappedOrders.map(o => o.dateStr).filter(Boolean))].sort()
      const latestDate = allDates.length > 0 ? allDates[allDates.length - 1] : null

      // Day change: yesterday vs day before yesterday
      const dayChange = dayBeforeYesterdayOrders > 0
        ? ((yesterdayOrders - dayBeforeYesterdayOrders) / dayBeforeYesterdayOrders * 100).toFixed(1)
        : null
      const monthChange = prevMonthOrders > 0
        ? ((monthOrders - prevMonthOrders) / prevMonthOrders * 100).toFixed(1)
        : null

      // Entrepreneur stats
      const entStats: Record<number, { id: number; name: string; totalOrders: number }> = {}
      for (const ent of targets) {
        entStats[ent.id] = { id: ent.id, name: ent.name, totalOrders: 0 }
      }
      for (const o of allMappedOrders) {
        if (!entStats[o.entrepreneurId]) {
          entStats[o.entrepreneurId] = { id: o.entrepreneurId, name: o.entrepreneurName, totalOrders: 0 }
        }
        entStats[o.entrepreneurId].totalOrders++
      }

      response.dashboard = {
        totalOrders,
        yesterdayOrders,
        dayBeforeYesterdayOrders,
        yesterdayDate: yesterdayMsk,
        monthOrders,
        prevMonthOrders,
        latestDate,
        dayChange,
        monthChange,
        entrepreneurStats: Object.values(entStats),
        productCount: productTypes.length,
      }
    }

    // ─── Build Daily ───
    if (needDaily) {
      const dailyDates = [...new Set(allMappedOrders.map(o => o.dateStr).filter(Boolean))].sort()
      const dailyProducts = productTypes.map((name, i) => ({ id: i, name }))
      const dailyProductMap = new Map(productTypes.map((name, i) => [name, i]))

      const dailyPivot: Record<number, Record<number, number>> = {}
      const dailyDateTotals: number[] = new Array(dailyDates.length).fill(0)
      const dailyProductTotals: Record<number, number> = {}

      for (const o of allMappedOrders) {
        const dateIdx = dailyDates.indexOf(o.dateStr)
        if (dateIdx === -1) continue

        const productId = dailyProductMap.get(o.mappedType)
        if (productId === undefined) continue

        if (!dailyPivot[productId]) dailyPivot[productId] = {}
        dailyPivot[productId][dateIdx] = (dailyPivot[productId][dateIdx] || 0) + 1
        dailyDateTotals[dateIdx]++
        dailyProductTotals[productId] = (dailyProductTotals[productId] || 0) + 1
      }

      response.daily = {
        dates: dailyDates,
        products: dailyProducts,
        pivot: dailyPivot,
        dateTotals: dailyDateTotals,
        productTotals: dailyProductTotals,
      }
    }

    // ─── Build Monthly ───
    if (needMonthly) {
      const monthsSet = new Set<string>()
      for (const o of allMappedOrders) {
        if (o.monthStr) monthsSet.add(o.monthStr)
      }
      const months = [...monthsSet].sort()

      const monthlyEntrepreneurs = targets.map(e => ({ id: e.id, name: e.name }))

      const monthlyData: Record<string, Record<number, number>> = {}
      const productMonthlyData: Record<string, Record<number, number>> = {}

      const dailyProductMap = new Map(productTypes.map((name, i) => [name, i]))

      // Initialize all months with zeros
      for (const m of months) {
        monthlyData[m] = {}
        productMonthlyData[m] = {}
        for (const ent of monthlyEntrepreneurs) {
          monthlyData[m][ent.id] = 0
        }
        for (const pt of productTypes) {
          const pid = dailyProductMap.get(pt)
          if (pid !== undefined) {
            productMonthlyData[m][pid] = 0
          }
        }
      }

      for (const o of allMappedOrders) {
        if (!o.monthStr || !monthlyData[o.monthStr]) continue

        monthlyData[o.monthStr][o.entrepreneurId] = (monthlyData[o.monthStr][o.entrepreneurId] || 0) + 1

        const productId = dailyProductMap.get(o.mappedType)
        if (productId !== undefined) {
          productMonthlyData[o.monthStr][productId] = (productMonthlyData[o.monthStr][productId] || 0) + 1
        }
      }

      const dailyProducts = productTypes.map((name, i) => ({ id: i, name }))

      response.monthly = {
        entrepreneurs: monthlyEntrepreneurs,
        products: dailyProducts,
        months,
        monthlyData,
        productMonthlyData,
      }
    }

    return NextResponse.json(response)
  } catch (e: any) {
    console.error('wb-data error:', e)
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
