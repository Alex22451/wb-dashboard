'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  LayoutDashboard,
  Table2,
  Calendar,
  Megaphone,
  TrendingUp,
  Package,
  GitCompare,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Key,
  Eye,
  EyeOff,
  Save,
  Trash2,
  Plus,
  Download,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { Skeleton } from '@/components/ui/skeleton'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
import { format, parseISO } from 'date-fns'
import { ru } from 'date-fns/locale'

// Types
interface DashboardData {
  totalOrders: number
  yesterdayOrders: number
  dayBeforeYesterdayOrders: number
  yesterdayDate: string | null
  monthOrders: number
  prevMonthOrders: number
  latestDate: string | null
  productCount: number
  entrepreneurStats: { id: number; name: string; totalOrders: number }[]
  dayChange: string | null
  monthChange: string | null
}

interface DailyOrdersData {
  dates: string[]
  products: { id: number; name: string }[]
  pivot: Record<number, Record<number, number>>
  dateTotals: number[]
  productTotals: Record<number, number>
}

interface EntrepreneurInfo {
  id: number
  name: string
  wbApiKey: string | null
  totalOrders: number
  hasApiKey: boolean
}

interface MonthlyData {
  entrepreneurs: { id: number; name: string }[]
  products: { id: number; name: string }[]
  months: string[]
  monthlyData: Record<string, Record<number, number>>
  productMonthlyData: Record<string, Record<number, number>>
}

interface AdSpendData {
  entrepreneurs: { id: number; name: string }[]
  grouped: Record<number, { entrepreneur: string; budget: number; months: { month: number; actual: number }[] }>
}

interface CompareData {
  entrepreneur: { id: number; name: string }
  dateRange: { from: string; to: string }
  dataSource: string
  wbError: string | null
  totals: {
    excelTotal: number
    wbTotal: number
    matchedExcelTotal: number
    matchedWbTotal: number
    totalDiff: number
    matchedDiff: number
  }
  productSummary: Array<{
    productId: number | null
    productName: string
    excelSize: string
    wbSize: string
    wbBySize: Record<string, number>
    wbSubject: string
    wbCategory: string
    excelTotal: number
    wbTotal: number
    diff: number
    diffPercent: string
    isMatched: boolean
    wbArticleCount: number
    matchMethod: string
  }>
  unmatchedBySubject: Array<{
    subject: string
    articleCount: number
    totalOrders: number
    examples: string[]
  }>
}

interface RateLimitError {
  id: number
  name: string
  error: string
}

const MONTH_SHORT = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']

function formatNumber(n: number): string {
  return n.toLocaleString('ru-RU')
}

function formatDateShort(dateStr: string): string {
  try {
    const d = parseISO(dateStr)
    return format(d, 'd MMM', { locale: ru })
  } catch {
    return dateStr
  }
}

function formatDateFull(dateStr: string): string {
  try {
    const d = parseISO(dateStr)
    return format(d, 'd MMMM yyyy', { locale: ru })
  } catch {
    return dateStr
  }
}

// --- Rate Limit Errors Alert ---
function RateLimitAlert({ errors }: { errors: RateLimitError[] }) {
  if (!errors || errors.length === 0) return null
  return (
    <Alert variant="destructive" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Превышен лимит запросов</AlertTitle>
      <AlertDescription>
        Не удалось загрузить данные для: {errors.map(e => e.name).join(', ')}. Попробуйте через минуту или выберите одно ИП.
      </AlertDescription>
    </Alert>
  )
}

// --- Empty State ---
function EmptyState({ message, icon }: { message: string; icon?: React.ReactNode }) {
  return (
    <Card className="border-dashed">
      <CardContent className="flex flex-col items-center justify-center py-16 text-center">
        {icon && <div className="mb-4 text-muted-foreground">{icon}</div>}
        <p className="text-muted-foreground text-lg font-medium">{message}</p>
      </CardContent>
    </Card>
  )
}

// --- Dashboard Tab ---
function DashboardTab({ data, entrepreneurs, selectedEnt, onSelectEnt, dataSource, onLoad, loading, rateLimitErrors }: {
  data: DashboardData | null
  entrepreneurs: EntrepreneurInfo[]
  selectedEnt: string
  onSelectEnt: (id: string) => void
  dataSource?: 'excel' | 'wbapi'
  onLoad: () => void
  loading: boolean
  rateLimitErrors: RateLimitError[]
}) {
  const dayChange = data?.dayChange
  const monthChange = data?.monthChange

  return (
    <div className="space-y-6">
      {/* Rate limit errors */}
      <RateLimitAlert errors={rateLimitErrors} />

      {/* ИП Selector + Load Button + Data Source */}
      <div className="flex flex-wrap items-center gap-3">
        <span className="text-sm font-medium text-muted-foreground">Показать:</span>
        <Select value={selectedEnt} onValueChange={onSelectEnt}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Выберите ИП" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все ИП (сводный)</SelectItem>
            {entrepreneurs.map((e) => (
              <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={onLoad} disabled={loading || !selectedEnt} className="gap-2">
          {loading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
              Загрузка...
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              Загрузить
            </>
          )}
        </Button>
        {data && (
          <Badge variant={dataSource === 'wbapi' ? 'default' : 'secondary'} className={`text-xs ${dataSource === 'wbapi' ? 'bg-emerald-600' : ''}`}>
            {dataSource === 'wbapi' ? '🔴 WB API (реальное время)' : '📊 Excel (кэш)'}
          </Badge>
        )}
      </div>

      {/* Loading skeleton */}
      {loading && <DashboardSkeleton />}

      {/* Empty state when no data and not loading */}
      {!loading && !data && (
        <EmptyState
          message={selectedEnt ? 'Нажмите "Загрузить" для получения данных' : 'Выберите ИП и нажмите "Загрузить"'}
          icon={<LayoutDashboard className="h-12 w-12" />}
        />
      )}

      {/* Data display */}
      {!loading && data && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Вчера</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(data.yesterdayOrders)}</div>
                {data.yesterdayDate && (
                  <p className="text-xs text-muted-foreground mt-1">{formatDateFull(data.yesterdayDate)}</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">К позавчера</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {dayChange !== null ? (
                    <span className={Number(dayChange) >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                      {Number(dayChange) >= 0 ? '+' : ''}{dayChange}%
                    </span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">было: {formatNumber(data.dayBeforeYesterdayOrders)}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">За текущий месяц</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(data.monthOrders)}</div>
                <p className="text-xs text-muted-foreground mt-1">заказов</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">К предыдущему месяцу</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {monthChange !== null ? (
                    <span className={Number(monthChange) >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                      {Number(monthChange) >= 0 ? '+' : ''}{monthChange}%
                    </span>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">было: {formatNumber(data.prevMonthOrders)}</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">Заказы по ИП <Badge variant="secondary" className="text-xs">WB API</Badge></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {data.entrepreneurStats
                  .sort((a, b) => b.totalOrders - a.totalOrders)
                  .map((e) => {
                    const pct = data.totalOrders > 0 ? (e.totalOrders / data.totalOrders) * 100 : 0
                    const ent = entrepreneurs.find(en => en.id === e.id)
                    return (
                      <div key={e.id} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium flex items-center gap-2">
                            {e.name}
                            {ent?.hasApiKey && <Badge variant="secondary" className="text-xs">API</Badge>}
                          </span>
                          <span className="text-muted-foreground">{formatNumber(e.totalOrders)}</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-20" />
              <Skeleton className="h-3 w-32 mt-2" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

// --- Data Table Component (shared) ---
function DataTable({ data }: { data: DailyOrdersData }) {
  const { dates, products, pivot, dateTotals, productTotals } = data
  const grandTotal = productTotals ? Object.values(productTotals).reduce((s, v) => s + v, 0) : 0

  if (dates.length === 0) {
    return (
      <div className="border rounded-lg p-8 text-center text-muted-foreground">
        Нет данных за выбранный период
      </div>
    )
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <ScrollArea className="w-full">
        <table className="text-sm">
          <thead>
            <tr className="bg-muted/50 border-b">
              <th className="text-left px-3 py-2 font-medium min-w-[200px] sticky left-0 bg-muted/50 z-10">Продукт</th>
              <th className="text-right px-3 py-2 font-medium min-w-[80px] bg-muted/50">Итого</th>
              {dates.map((d) => (
                <th key={d} className="text-right px-3 py-2 font-medium min-w-[60px] whitespace-nowrap" title={formatDateFull(d)}>
                  {formatDateShort(d)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr className="bg-emerald-50 dark:bg-emerald-950/20 border-b font-semibold">
              <td className="px-3 py-2 sticky left-0 bg-emerald-50 dark:bg-emerald-950/20 z-10">ИТОГО</td>
              <td className="text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20">{formatNumber(grandTotal)}</td>
              {dates.map((d, i) => (
                <td key={d} className="text-right px-3 py-2">{formatNumber(dateTotals[i] || 0)}</td>
              ))}
            </tr>
            {products.map((p) => {
              const total = productTotals?.[p.id] || 0
              const productPivot = pivot[p.id]
              if (!productPivot || total === 0) return null
              const hasVisibleData = dates.some((_, i) => productPivot[i])
              if (!hasVisibleData && total === 0) return null
              return (
                <tr key={p.id} className="border-b hover:bg-muted/30 transition-colors">
                  <td className="px-3 py-2 sticky left-0 bg-background z-10">{p.name}</td>
                  <td className="text-right px-3 py-2 font-medium">{formatNumber(total)}</td>
                  {dates.map((d, i) => {
                    const val = productPivot[i]
                    return (
                      <td key={d} className={`text-right px-3 py-2 ${val ? '' : 'text-muted-foreground'}`}>
                        {val || '—'}
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}

// --- Daily Orders Tab ---
function DailyOrdersTab({ entrepreneurs }: { entrepreneurs: EntrepreneurInfo[] }) {
  const [fetchedData, setFetchedData] = useState<DailyOrdersData | null>(null)
  const [loading, setLoading] = useState(false)
  const [selectedEnt, setSelectedEnt] = useState<string>('all')
  const [rateLimitErrors, setRateLimitErrors] = useState<RateLimitError[]>([])
  // Default to yesterday in Moscow timezone (последний день = yesterday, not today)
  const getYesterday = () => {
    const mskOffset = 3 * 60 * 60 * 1000
    const nowMsk = new Date(Date.now() + mskOffset)
    nowMsk.setDate(nowMsk.getDate() - 1)
    return nowMsk.toISOString().split('T')[0]
  }

  const [dateMode, setDateMode] = useState<'single' | 'range'>('single')
  const [singleDate, setSingleDate] = useState<string>(getYesterday())
  const [dateFrom, setDateFrom] = useState<string>(getYesterday())
  const [dateTo, setDateTo] = useState<string>(getYesterday())

  const fetchData = useCallback(async () => {
    setLoading(true)
    setRateLimitErrors([])
    try {
      const params = new URLSearchParams()
      params.set('entrepreneurId', selectedEnt)
      params.set('section', 'daily')
      if (dateMode === 'single' && singleDate) {
        params.set('dateFrom', singleDate)
        params.set('dateTo', singleDate)
      } else if (dateMode === 'range') {
        if (dateFrom) params.set('dateFrom', dateFrom)
        if (dateTo) params.set('dateTo', dateTo)
      }
      const res = await fetch(`/api/wb-data?${params.toString()}`)
      const json = await res.json()
      if (json.daily) setFetchedData(json.daily)
      if (json.rateLimitErrors) setRateLimitErrors(json.rateLimitErrors)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [selectedEnt, dateMode, singleDate, dateFrom, dateTo])

  // NO auto-fetch on mount — only fetch when user clicks "Показать"

  return (
    <div className="space-y-4">
      {/* Rate limit errors */}
      <RateLimitAlert errors={rateLimitErrors} />

      <div className="flex flex-wrap items-center gap-3">
        <Select value={selectedEnt} onValueChange={setSelectedEnt}>
          <SelectTrigger className="w-56">
            <SelectValue placeholder="Все ИП" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все ИП (сводный)</SelectItem>
            {entrepreneurs.map((e) => (
              <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <ToggleGroup type="single" value={dateMode} onValueChange={(v) => { if (v) setDateMode(v as 'single' | 'range') }} className="border rounded-md">
          <ToggleGroupItem value="single" className="text-xs px-3">Один день</ToggleGroupItem>
          <ToggleGroupItem value="range" className="text-xs px-3">Диапазон</ToggleGroupItem>
        </ToggleGroup>

        {dateMode === 'single' ? (
          <Input type="date" value={singleDate} onChange={(e) => setSingleDate(e.target.value)} className="w-40" min="2026-01-01" max="2026-12-31" />
        ) : (
          <div className="flex items-center gap-2">
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" min="2026-01-01" max="2026-12-31" />
            <span className="text-sm text-muted-foreground">—</span>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" min="2026-01-01" max="2026-12-31" />
          </div>
        )}

        <Button onClick={fetchData} disabled={loading} className="gap-2">
          {loading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
              Загрузка...
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              Показать
            </>
          )}
        </Button>
      </div>

      {loading ? (
        <Skeleton className="h-96 w-full" />
      ) : fetchedData ? (
        <DataTable data={fetchedData} />
      ) : (
        <EmptyState
          message="Выберите ИП, дату и нажмите «Показать»"
          icon={<Table2 className="h-12 w-12" />}
        />
      )}
    </div>
  )
}

// --- Monthly Tab ---
function MonthlyTab({ entrepreneurs }: { entrepreneurs: EntrepreneurInfo[] }) {
  const [fetchedData, setFetchedData] = useState<MonthlyData | null>(null)
  const [loading, setLoading] = useState(false)
  const [view, setView] = useState<'entrepreneurs' | 'products'>('entrepreneurs')
  const [selectedEnt, setSelectedEnt] = useState<string>('all')
  const [rateLimitErrors, setRateLimitErrors] = useState<RateLimitError[]>([])

  // Use fetchedData
  const data = fetchedData

  // Compute sorted entrepreneur table data when data is available
  const entTableData = data ? data.entrepreneurs.map((e) => {
    const row: Record<string, number> = {}
    data.months.forEach((m) => { row[m] = data.monthlyData[m]?.[e.id] || 0 })
    const total = data.months.reduce((s, m) => s + (data.monthlyData[m]?.[e.id] || 0), 0)
    return { ...e, data: row, total }
  }).sort((a, b) => b.total - a.total) : []

  const fetchData = useCallback(async () => {
    setLoading(true)
    setRateLimitErrors([])
    try {
      const params = new URLSearchParams()
      params.set('entrepreneurId', selectedEnt)
      params.set('section', 'monthly')
      const res = await fetch(`/api/wb-data?${params.toString()}`)
      const json = await res.json()
      if (json.monthly) setFetchedData(json.monthly)
      if (json.rateLimitErrors) setRateLimitErrors(json.rateLimitErrors)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [selectedEnt])

  // NO auto-fetch on mount — only fetch when user clicks "Загрузить"

  return (
    <div className="space-y-6">
      {/* Rate limit errors */}
      <RateLimitAlert errors={rateLimitErrors} />

      <div className="flex flex-wrap items-center gap-3">
        <Select value={selectedEnt} onValueChange={setSelectedEnt}>
          <SelectTrigger className="w-56">
            <SelectValue placeholder="Все ИП" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все ИП (сводный)</SelectItem>
            {entrepreneurs.map((e) => (
              <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={view} onValueChange={(v) => setView(v as 'entrepreneurs' | 'products')}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="entrepreneurs">По ИП</SelectItem>
            <SelectItem value="products">По продуктам (Топ-10)</SelectItem>
          </SelectContent>
        </Select>

        <Button onClick={fetchData} disabled={loading} className="gap-2">
          {loading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
              Загрузка...
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              Загрузить
            </>
          )}
        </Button>
      </div>

      {loading && <Skeleton className="h-96 w-full" />}

      {!loading && !data && (
        <EmptyState
          message="Выберите ИП и нажмите «Загрузить»"
          icon={<Calendar className="h-12 w-12" />}
        />
      )}

      {!loading && data && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">
                {view === 'entrepreneurs' ? 'Заказы по ИП по месяцам' : 'Топ-10 продуктов по месяцам'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthsChartData(data, view)} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip formatter={(value: number) => formatNumber(value)} contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    {(view === 'entrepreneurs' ? data.entrepreneurs : data.products.slice(0, 10)).map((item, i) => (
                      <Bar key={item.id} dataKey={item.name.length > 20 ? item.name.slice(0, 20) + '…' : item.name} fill={COLORS[i % COLORS.length]} radius={[2, 2, 0, 0]} />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {view === 'entrepreneurs' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">Помесячная сводка по ИП <Badge variant="secondary" className="text-xs">WB API</Badge></CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="w-full">
                  <table className="text-sm">
                    <thead>
                      <tr className="bg-muted/50 border-b">
                        <th className="text-left px-3 py-2 font-medium sticky left-0 bg-muted/50 z-10">ИП</th>
                        {data.months.map((m) => {
                          const [y, mo] = m.split('-')
                          return <th key={m} className="text-right px-3 py-2 font-medium min-w-[80px]">{MONTH_SHORT[Number(mo) - 1]} {y.slice(2)}</th>
                        })}
                        <th className="text-right px-3 py-2 font-medium min-w-[80px] bg-muted/50">Итого</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const entTableData = data.entrepreneurs.map((e) => {
                          const row: Record<string, number> = {}
                          data.months.forEach((m) => { row[m] = data.monthlyData[m]?.[e.id] || 0 })
                          const total = data.months.reduce((s, m) => s + (data.monthlyData[m]?.[e.id] || 0), 0)
                          return { ...e, data: row, total }
                        }).sort((a, b) => b.total - a.total)
                        return entTableData.map((e) => (
                          <tr key={e.id} className="border-b hover:bg-muted/30 transition-colors">
                            <td className="px-3 py-2 sticky left-0 bg-background z-10 font-medium">{e.name}</td>
                            {data.months.map((m) => (<td key={m} className="text-right px-3 py-2">{formatNumber(e.data[m])}</td>))}
                            <td className="text-right px-3 py-2 font-semibold bg-muted/30">{formatNumber(e.total)}</td>
                          </tr>
                        ))
                      })()}
                      <tr className="bg-emerald-50 dark:bg-emerald-950/20 font-semibold">
                        <td className="px-3 py-2 sticky left-0 bg-emerald-50 dark:bg-emerald-950/20 z-10">ИТОГО</td>
                        {data.months.map((m) => {
                          const total = data.entrepreneurs.reduce((s, e) => s + (data.monthlyData[m]?.[e.id] || 0), 0)
                          return <td key={m} className="text-right px-3 py-2">{formatNumber(total)}</td>
                        })}
                        <td className="text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20">
                          {formatNumber(data.entrepreneurs.reduce((s, e) => s + data.months.reduce((ss, m) => ss + (data.monthlyData[m]?.[e.id] || 0), 0), 0))}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}

const COLORS = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#64748b', '#ec4899', '#14b8a6', '#a855f7']

function monthsChartData(data: MonthlyData, view: 'entrepreneurs' | 'products') {
  return data.months.map((m) => {
    const entry: Record<string, any> = { month: m }
    if (view === 'entrepreneurs') {
      data.entrepreneurs.forEach((e) => {
        entry[e.name] = data.monthlyData[m]?.[e.id] || 0
      })
    } else {
      const productTotals = data.products.map((p) => ({
        ...p,
        total: Object.values(data.productMonthlyData).reduce((s, monthData) => s + (monthData[p.id] || 0), 0),
      })).sort((a, b) => b.total - a.total).slice(0, 10)
      productTotals.forEach((p) => {
        entry[p.name.length > 20 ? p.name.slice(0, 20) + '…' : p.name] = data.productMonthlyData[m]?.[p.id] || 0
      })
    }
    return entry
  })
}

// --- Ad Spend Tab ---
function AdSpendTab() {
  const [data, setData] = useState<AdSpendData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/ad-spend').then((r) => r.json()).then(setData).catch(console.error).finally(() => setLoading(false))
  }, [])

  if (loading || !data) return <Skeleton className="h-96 w-full" />

  const { grouped } = data
  const entries = Object.values(grouped)
  const chartData = Array.from({ length: 12 }, (_, i) => {
    const entry: Record<string, any> = { month: MONTH_SHORT[i] }
    entries.forEach((e) => { const monthData = e.months.find((m) => m.month === i + 1); entry[e.entrepreneur] = monthData?.actual || 0 })
    return entry
  })
  const colors = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#64748b']

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader><CardTitle className="text-base">Расходы на рекламу по месяцам (2026)</CardTitle></CardHeader>
        <CardContent>
          {entries.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">Нет данных о расходах на рекламу за 2026 год</p>
          ) : (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}к`} />
                  <Tooltip formatter={(value: number) => `${formatNumber(value)} ₽`} contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                  <Legend wrapperStyle={{ fontSize: '12px' }} />
                  {entries.map((e, i) => (<Bar key={e.entrepreneur} dataKey={e.entrepreneur} fill={colors[i % colors.length]} radius={[2, 2, 0, 0]} />))}
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
      {entries.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Расходы на рекламу — детализация (2026)</CardTitle></CardHeader>
          <CardContent>
            <ScrollArea className="w-full">
              <table className="text-sm">
                <thead>
                  <tr className="bg-muted/50 border-b">
                    <th className="text-left px-3 py-2 font-medium sticky left-0 bg-muted/50 z-10">ИП</th>
                    <th className="text-right px-3 py-2 font-medium min-w-[90px] bg-muted/50">Бюджет/мес</th>
                    {MONTH_SHORT.map((m) => (<th key={m} className="text-right px-3 py-2 font-medium min-w-[80px]">{m}</th>))}
                    <th className="text-right px-3 py-2 font-medium min-w-[90px] bg-muted/50">Итого</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((e, idx) => {
                    const total = e.months.reduce((s, m) => s + m.actual, 0)
                    return (
                      <tr key={idx} className="border-b hover:bg-muted/30 transition-colors">
                        <td className="px-3 py-2 sticky left-0 bg-background z-10 font-medium">{e.entrepreneur}</td>
                        <td className="text-right px-3 py-2 text-muted-foreground">{formatNumber(e.budget)}</td>
                        {Array.from({ length: 12 }, (_, i) => { const monthData = e.months.find((m) => m.month === i + 1); return (<td key={i} className={`text-right px-3 py-2 ${monthData ? '' : 'text-muted-foreground'}`}>{monthData ? formatNumber(monthData.actual) : '—'}</td>); })}
                        <td className="text-right px-3 py-2 font-semibold bg-muted/30">{formatNumber(total)}</td>
                      </tr>
                    )
                  })}
                  <tr className="bg-emerald-50 dark:bg-emerald-950/20 font-semibold">
                    <td className="px-3 py-2 sticky left-0 bg-emerald-50 dark:bg-emerald-950/20 z-10">ИТОГО</td>
                    <td className="text-right px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20">{formatNumber(entries.reduce((s, e) => s + e.budget, 0))}</td>
                    {Array.from({ length: 12 }, (_, i) => { const monthTotal = entries.reduce((s, e) => { const md = e.months.find((m) => m.month === i + 1); return s + (md?.actual || 0) }, 0); return (<td key={i} className="text-right px-3 py-2">{monthTotal ? formatNumber(monthTotal) : '—'}</td>); })}
                    <td className="text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20">{formatNumber(entries.reduce((s, e) => s + e.months.reduce((ss, m) => ss + m.actual, 0), 0))}</td>
                  </tr>
                </tbody>
              </table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// --- WB Compare Tab ---
function WbCompareTab({ entrepreneurs }: { entrepreneurs: EntrepreneurInfo[] }) {
  const [data, setData] = useState<CompareData | null>(null)
  const [loading, setLoading] = useState(false)
  const [selectedEnt, setSelectedEnt] = useState<string>('5') // Масляков А.А. by default
  const [dateFrom, setDateFrom] = useState<string>('2026-04-01')
  const [dateTo, setDateTo] = useState<string>('2026-04-29')
  const apiEntrepreneurs = entrepreneurs.filter((e) => e.hasApiKey)

  const fetchData = useCallback(async () => {
    if (!selectedEnt) return
    setLoading(true)
    try {
      const params = new URLSearchParams({
        entrepreneurId: selectedEnt,
        ...(dateFrom ? { dateFrom } : {}),
        ...(dateTo ? { dateTo } : {}),
      })
      const res = await fetch(`/api/wb-compare?${params.toString()}`)
      const json = await res.json()
      setData(json)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [selectedEnt, dateFrom, dateTo])

  const selectedEntrepreneur = entrepreneurs.find((e) => String(e.id) === selectedEnt)

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3">
        <Select value={selectedEnt} onValueChange={setSelectedEnt}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Выберите ИП" />
          </SelectTrigger>
          <SelectContent>
            {apiEntrepreneurs.length > 0 ? (
              apiEntrepreneurs.map((e) => (
                <SelectItem key={e.id} value={String(e.id)}>{e.name} 🔑</SelectItem>
              ))
            ) : (
              <SelectItem value="none" disabled>Нет ИП с API ключом</SelectItem>
            )}
          </SelectContent>
        </Select>

        <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" min="2026-01-01" max="2026-12-31" />
        <span className="text-sm text-muted-foreground">—</span>
        <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" min="2026-01-01" max="2026-12-31" />

        <Button onClick={fetchData} disabled={loading || !selectedEnt || selectedEnt === 'none'}>
          {loading ? 'Загрузка...' : 'Сравнить'}
        </Button>
      </div>

      {/* No API keys message */}
      {apiEntrepreneurs.length === 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Нет API ключей</AlertTitle>
          <AlertDescription>
            Для сравнения данных необходимо добавить API ключ Wildberries хотя бы для одного ИП.
            Добавьте ключ в настройках базы данных.
          </AlertDescription>
        </Alert>
      )}

      {/* Loading */}
      {loading && <Skeleton className="h-96 w-full" />}

      {/* Data */}
      {data && !loading && (
        <div className="space-y-4">
          {/* Data source indicator */}
          {data.dataSource && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                Источник WB: {data.dataSource === 'sales' ? 'Продажи (Sales API)' : 'Заказы (Orders API)'}
              </span>
              <span>— Продажи точнее отражают реальные данные</span>
            </div>
          )}

          {/* API Error */}
          {data.wbError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Ошибка WB API</AlertTitle>
              <AlertDescription>{data.wbError}</AlertDescription>
            </Alert>
          )}

          {/* Summary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Excel (таблица)</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(data.totals.excelTotal)}</div>
                <p className="text-xs text-muted-foreground mt-1">заказов за период</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">WB API</CardTitle>
                <GitCompare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(data.totals.wbTotal)}</div>
                <p className="text-xs text-muted-foreground mt-1">заказов за период</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Разница</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <span className={data.totals.totalDiff >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                    {data.totals.totalDiff >= 0 ? '+' : ''}{formatNumber(data.totals.totalDiff)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">API − Excel</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Сопоставлено</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {data.productSummary ? data.productSummary.filter((c) => c.isMatched).length : 0} / {data.productSummary?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-1">товаров с API</p>
              </CardContent>
            </Card>
          </div>

          {/* Product Summary - each product with size */}
          {data.productSummary && data.productSummary.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Сравнение по товарам: {selectedEntrepreneur?.name} — Excel vs WB API
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="w-full">
                  <table className="text-sm">
                    <thead>
                      <tr className="bg-muted/50 border-b">
                        <th className="text-left px-3 py-2 font-medium sticky left-0 bg-muted/50 z-10 min-w-[220px]">Товар (Excel)</th>
                        <th className="text-left px-3 py-2 font-medium min-w-[80px]">Размер</th>
                        <th className="text-center px-3 py-2 font-medium min-w-[50px]">Арт.</th>
                        <th className="text-left px-3 py-2 font-medium min-w-[130px]">API предмет</th>
                        <th className="text-left px-3 py-2 font-medium min-w-[100px]">Метод</th>
                        <th className="text-right px-3 py-2 font-medium min-w-[70px]">Excel</th>
                        <th className="text-right px-3 py-2 font-medium min-w-[70px]">API</th>
                        <th className="text-right px-3 py-2 font-medium min-w-[70px]">Разница</th>
                        <th className="text-right px-3 py-2 font-medium min-w-[60px]">%</th>
                        <th className="text-center px-3 py-2 font-medium min-w-[40px]"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Grand totals */}
                      <tr className="bg-emerald-50 dark:bg-emerald-950/20 border-b font-semibold">
                        <td className="px-3 py-2 sticky left-0 bg-emerald-50 dark:bg-emerald-950/20 z-10">ИТОГО</td>
                        <td className="px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20" />
                        <td className="px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20" />
                        <td className="px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20" />
                        <td className="px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20" />
                        <td className="text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20">{formatNumber(data.totals.excelTotal)}</td>
                        <td className="text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20">{formatNumber(data.totals.wbTotal)}</td>
                        <td className={`text-right px-3 py-2 font-bold bg-emerald-50 dark:bg-emerald-950/20 ${data.totals.totalDiff >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                          {data.totals.totalDiff >= 0 ? '+' : ''}{formatNumber(data.totals.totalDiff)}
                        </td>
                        <td className="text-right px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20">
                          {data.totals.excelTotal > 0 ? ((data.totals.totalDiff / data.totals.excelTotal) * 100).toFixed(1) : '—'}%
                        </td>
                        <td className="px-3 py-2 bg-emerald-50 dark:bg-emerald-950/20" />
                      </tr>

                      {/* Product rows */}
                      {data.productSummary.map((item, idx) => {
                        const isExact = item.isMatched && item.diff === 0
                        const hasDiff = item.isMatched && item.diff !== 0

                        return (
                          <tr key={idx} className={`border-b hover:bg-muted/30 transition-colors ${!item.isMatched ? 'bg-amber-50/50 dark:bg-amber-950/5' : ''}`}>
                            <td className="px-3 py-2 sticky left-0 bg-background z-10">
                              <span className={!item.isMatched ? 'text-amber-600' : ''}>{item.productName}</span>
                            </td>
                            <td className="px-3 py-2">
                              {item.excelSize ? (
                                <Badge variant="outline" className="text-xs font-mono">{item.excelSize}</Badge>
                              ) : '—'}
                            </td>
                            <td className="text-center px-3 py-2">
                              {item.wbArticleCount > 0 ? (
                                <Badge variant="secondary" className="text-xs">{item.wbArticleCount}</Badge>
                              ) : '—'}
                            </td>
                            <td className="px-3 py-2 text-muted-foreground text-xs">
                              {item.wbSubject || '—'}
                            </td>
                            <td className="px-3 py-2 text-xs">
                              {item.matchMethod ? (
                                <Badge variant="outline" className="text-[10px] font-normal">{item.matchMethod}</Badge>
                              ) : '—'}
                            </td>
                            <td className="text-right px-3 py-2">{item.excelTotal || '—'}</td>
                            <td className="text-right px-3 py-2">{item.wbTotal || '—'}</td>
                            <td className={`text-right px-3 py-2 font-medium ${item.diff > 0 ? 'text-emerald-600' : item.diff < 0 ? 'text-red-600' : ''}`}>
                              {item.diff !== 0 ? `${item.diff > 0 ? '+' : ''}${formatNumber(item.diff)}` : '0'}
                            </td>
                            <td className="text-right px-3 py-2 text-muted-foreground">{item.diffPercent !== '—' ? `${item.diffPercent}%` : '—'}</td>
                            <td className="text-center px-3 py-2">
                              {isExact ? (
                                <CheckCircle2 className="h-4 w-4 text-emerald-500 mx-auto" />
                              ) : hasDiff ? (
                                <AlertCircle className="h-4 w-4 text-amber-500 mx-auto" />
                              ) : !item.isMatched ? (
                                <XCircle className="h-4 w-4 text-red-400 mx-auto" />
                              ) : null}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Unmatched WB Articles by Subject */}
          {data.unmatchedBySubject && data.unmatchedBySubject.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-amber-500" />
                  Несопоставленные артикулы WB API
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="w-full">
                  <table className="text-sm">
                    <thead>
                      <tr className="bg-muted/50 border-b">
                        <th className="text-left px-3 py-2 font-medium">Предмет (WB)</th>
                        <th className="text-right px-3 py-2 font-medium">Артикулов</th>
                        <th className="text-right px-3 py-2 font-medium">Заказов</th>
                        <th className="text-left px-3 py-2 font-medium">Примеры</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.unmatchedBySubject.map((item, idx) => (
                        <tr key={idx} className="border-b hover:bg-muted/30 transition-colors">
                          <td className="px-3 py-2 font-medium">{item.subject}</td>
                          <td className="text-right px-3 py-2">{item.articleCount}</td>
                          <td className="text-right px-3 py-2 font-medium">{formatNumber(item.totalOrders)}</td>
                          <td className="px-3 py-2 text-xs text-muted-foreground">
                            {item.examples.map((ex, i) => (
                              <span key={i} className="inline-block mr-1 mb-1">
                                <Badge variant="outline" className="text-[10px] font-mono">{ex}</Badge>
                              </span>
                            ))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              </CardContent>
            </Card>
          )}

        </div>
      )}
    </div>
  )
}

// --- API Key Management Tab ---
function ApiKeyTab({ entrepreneurs, onRefresh }: { entrepreneurs: EntrepreneurInfo[]; onRefresh: () => void }) {
  const [showKey, setShowKey] = useState<Record<number, boolean>>({})
  const [deleting, setDeleting] = useState<number | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [dialogEntId, setDialogEntId] = useState<string>('')
  const [dialogKey, setDialogKey] = useState<string>('')
  const [dialogSaving, setDialogSaving] = useState(false)

  const handleSave = async (entId: number, apiKey: string) => {
    if (!apiKey.trim()) return
    setDialogSaving(true)
    try {
      const res = await fetch('/api/save-api-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entrepreneurId: entId, apiKey: apiKey.trim() }),
      })
      if (res.ok) {
        onRefresh()
        setDialogOpen(false)
        setDialogKey('')
        setDialogEntId('')
      }
    } catch (e) {
      console.error(e)
    } finally {
      setDialogSaving(false)
    }
  }

  const handleDelete = async (entId: number) => {
    setDeleting(entId)
    try {
      const res = await fetch(`/api/save-api-key?entrepreneurId=${entId}`, { method: 'DELETE' })
      if (res.ok) {
        onRefresh()
      }
    } catch (e) {
      console.error(e)
    } finally {
      setDeleting(null)
    }
  }

  const openAddDialog = (entId?: number) => {
    if (entId) {
      setDialogEntId(String(entId))
    } else {
      setDialogEntId('')
    }
    setDialogKey('')
    setDialogOpen(true)
  }

  const toggleShowKey = (entId: number) => {
    setShowKey(prev => ({ ...prev, [entId]: !prev[entId] }))
  }

  const maskKey = (key: string) => {
    if (key.length <= 8) return '••••••••'
    return key.substring(0, 4) + '••••••••' + key.substring(key.length - 4)
  }

  const withKeys = entrepreneurs.filter(e => e.hasApiKey)
  const withoutKeys = entrepreneurs.filter(e => !e.hasApiKey)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Key className="h-5 w-5" />
            API Ключи Wildberries
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Управление API ключами для доступа к данным WB. {withKeys.length} из {entrepreneurs.length} ИП имеют ключи.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => openAddDialog()} className="gap-2">
              <Plus className="h-4 w-4" />
              Добавить ключ
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Добавить API ключ</DialogTitle>
              <DialogDescription>
                Введите API ключ Wildberries для выбранного ИП. Ключ можно получить в личном кабинете WB → Настройки → Доступ к API.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>ИП</Label>
                <Select value={dialogEntId} onValueChange={setDialogEntId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите ИП" />
                  </SelectTrigger>
                  <SelectContent>
                    {entrepreneurs.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.name} {e.hasApiKey ? '🔑' : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>API Ключ</Label>
                <Input
                  type="text"
                  placeholder="Вставьте API ключ..."
                  value={dialogKey}
                  onChange={(e) => setDialogKey(e.target.value)}
                  className="font-mono text-sm"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Отмена</Button>
              <Button
                onClick={() => handleSave(Number(dialogEntId), dialogKey)}
                disabled={!dialogEntId || !dialogKey.trim() || dialogSaving}
                className="gap-2"
              >
                <Save className="h-4 w-4" />
                {dialogSaving ? 'Сохранение...' : 'Сохранить'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Всего ИП</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{entrepreneurs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">С API ключом</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{withKeys.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Без ключа</CardTitle>
            <XCircle className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{withoutKeys.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Entrepreneurs with keys */}
      {withKeys.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              🔑 ИП с API ключами
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {withKeys.map((e) => (
                <div key={e.id} className="flex items-center justify-between p-3 rounded-lg border bg-emerald-50/50 dark:bg-emerald-950/10">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center">
                      <Key className="h-4 w-4 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{e.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">
                        {showKey[e.id] && e.wbApiKey ? e.wbApiKey : (e.wbApiKey ? maskKey(e.wbApiKey) : '—')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => toggleShowKey(e.id)}>
                      {showKey[e.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => openAddDialog(e.id)} className="text-muted-foreground">
                      <Save className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(e.id)}
                      disabled={deleting === e.id}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Entrepreneurs without keys */}
      {withoutKeys.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              🔒 ИП без API ключей
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {withoutKeys.map((e) => (
                <div key={e.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                      <XCircle className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{e.name}</p>
                      <p className="text-xs text-muted-foreground">API ключ не добавлен</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => openAddDialog(e.id)} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Добавить
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// --- Main Page ---
export default function Home() {
  const [dashboard, setDashboard] = useState<DashboardData | null>(null)
  const [entrepreneurs, setEntrepreneurs] = useState<EntrepreneurInfo[]>([])
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedDashEnt, setSelectedDashEnt] = useState<string>('') // Empty = no auto-fetch
  const [dashboardLoading, setDashboardLoading] = useState(false)
  const [dataSource, setDataSource] = useState<'excel' | 'wbapi'>('excel')
  const [rateLimitErrors, setRateLimitErrors] = useState<RateLimitError[]>([])

  // Fetch entrepreneurs list on mount (local DB only, no WB API)
  useEffect(() => {
    fetch('/api/entrepreneurs').then((r) => r.json()).then(setEntrepreneurs).catch(console.error)
  }, [])

  const refreshEntrepreneurs = useCallback(() => {
    fetch('/api/entrepreneurs').then((r) => r.json()).then(setEntrepreneurs).catch(console.error)
  }, [])

  // Explicit dashboard data load — only triggered by user clicking "Загрузить"
  const loadDashboardData = useCallback(async () => {
    if (!selectedDashEnt) return
    setDashboardLoading(true)
    setRateLimitErrors([])
    try {
      const params = new URLSearchParams()
      params.set('entrepreneurId', selectedDashEnt)
      params.set('section', 'dashboard')
      const res = await fetch(`/api/wb-data?${params.toString()}`)
      const json = await res.json()
      if (json.dashboard) {
        setDashboard(json.dashboard)
        setDataSource('wbapi')
      }
      if (json.rateLimitErrors) setRateLimitErrors(json.rateLimitErrors)
    } catch (e) {
      console.error(e)
    } finally {
      setDashboardLoading(false)
    }
  }, [selectedDashEnt])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-emerald-600 flex items-center justify-center">
              <Package className="h-4 w-4 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">WB Отчёты</h1>
              <p className="text-xs text-muted-foreground">Ежедневная аналитика заказов • 2026</p>
            </div>
          </div>
          {dashboard?.latestDate && (
            <Badge variant="outline" className="text-xs">
              Данные по: {formatDateFull(dashboard.latestDate)}
            </Badge>
          )}
        </div>
      </header>

      <main className="flex-1 max-w-[1600px] mx-auto w-full px-4 sm:px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 flex-wrap h-auto gap-1">
            <TabsTrigger value="dashboard" className="gap-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Сводка</span>
            </TabsTrigger>
            <TabsTrigger value="daily" className="gap-2">
              <Table2 className="h-4 w-4" />
              <span className="hidden sm:inline">Ежедневные</span>
            </TabsTrigger>
            <TabsTrigger value="monthly" className="gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">По месяцам</span>
            </TabsTrigger>
            <TabsTrigger value="ads" className="gap-2">
              <Megaphone className="h-4 w-4" />
              <span className="hidden sm:inline">Реклама</span>
            </TabsTrigger>
            <TabsTrigger value="compare" className="gap-2">
              <GitCompare className="h-4 w-4" />
              <span className="hidden sm:inline">API vs Excel</span>
            </TabsTrigger>
            <TabsTrigger value="apikeys" className="gap-2">
              <Key className="h-4 w-4" />
              <span className="hidden sm:inline">API Ключи</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DashboardTab
              data={dashboard}
              entrepreneurs={entrepreneurs}
              selectedEnt={selectedDashEnt}
              onSelectEnt={setSelectedDashEnt}
              dataSource={dataSource}
              onLoad={loadDashboardData}
              loading={dashboardLoading}
              rateLimitErrors={rateLimitErrors}
            />
          </TabsContent>
          <TabsContent value="daily">
            <DailyOrdersTab entrepreneurs={entrepreneurs} />
          </TabsContent>
          <TabsContent value="monthly">
            <MonthlyTab entrepreneurs={entrepreneurs} />
          </TabsContent>
          <TabsContent value="ads">
            <AdSpendTab />
          </TabsContent>
          <TabsContent value="compare">
            <WbCompareTab entrepreneurs={entrepreneurs} />
          </TabsContent>
          <TabsContent value="apikeys">
            <ApiKeyTab entrepreneurs={entrepreneurs} onRefresh={refreshEntrepreneurs} />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t mt-auto">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-4">
          <p className="text-xs text-muted-foreground text-center">
            WB Отчёты — Аналитика заказов Wildberries • 2026 • {entrepreneurs.length} ИП
          </p>
        </div>
      </footer>
    </div>
  )
}
