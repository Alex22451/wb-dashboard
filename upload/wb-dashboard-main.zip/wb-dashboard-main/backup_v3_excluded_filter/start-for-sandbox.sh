#!/bin/bash
cd /home/z/my-project
echo "[$(date)] Sandbox startup script beginning" >> /home/z/my-project/dev.log
while true; do
  echo "[$(date)] Starting Next.js dev server..." >> /home/z/my-project/dev.log
  NODE_OPTIONS="--max-old-space-size=512" node node_modules/.bin/next dev -p 3000 --turbopack >> /home/z/my-project/dev.log 2>&1
  EXIT_CODE=$?
  echo "[$(date)] Server exited with code $EXIT_CODE, restarting in 3s..." >> /home/z/my-project/dev.log
  sleep 3
done
