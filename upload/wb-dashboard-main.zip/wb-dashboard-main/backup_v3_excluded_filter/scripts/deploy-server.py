#!/usr/bin/env python3
"""Deploy WB Analytics to remote server via SSH"""
import paramiko
import os
import tarfile
import tempfile
import io
import sys

HOST = '194.34.239.159'
USER = 'alex777'
PASS = '123456'
REMOTE_DIR = '/home/alex777/wb-analytics'
LOCAL_DIR = '/home/z/my-project'

def create_ssh_client():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASS, timeout=30)
    return client

def run_cmd(client, cmd, check=True):
    print(f"  $ {cmd}")
    stdin, stdout, stderr = client.exec_command(cmd, timeout=120)
    out = stdout.read().decode()
    err = stderr.read().decode()
    code = stdout.channel.recv_exit_status()
    if out.strip():
        print(f"    {out.strip()[:200]}")
    if err.strip() and code != 0:
        print(f"    STDERR: {err.strip()[:200]}")
    if check and code != 0:
        raise Exception(f"Command failed (code {code}): {cmd}\n{err}")
    return out, err, code

def create_archive():
    """Create a tar.gz archive of the project"""
    print("\n📦 Creating project archive...")
    
    # Files and directories to include
    include_dirs = ['src', 'prisma', 'public', 'scripts', 'db']
    include_files = ['package.json', 'next.config.ts', 'tsconfig.json', 'postcss.config.mjs', 
                     'tailwind.config.ts', 'components.json', 'eslint.config.mjs']
    
    archive_path = '/tmp/wb-analytics-deploy.tar.gz'
    
    with tarfile.open(archive_path, 'w:gz') as tar:
        for d in include_dirs:
            full_path = os.path.join(LOCAL_DIR, d)
            if os.path.exists(full_path):
                tar.add(full_path, arcname=d)
        for f in include_files:
            full_path = os.path.join(LOCAL_DIR, f)
            if os.path.exists(full_path):
                tar.add(full_path, arcname=f)
    
    size = os.path.getsize(archive_path)
    print(f"  Archive created: {size / 1024 / 1024:.1f} MB")
    return archive_path

def upload_file(client, local_path, remote_path):
    """Upload a file via SFTP"""
    sftp = client.open_sftp()
    sftp.put(local_path, remote_path)
    sftp.close()

def main():
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("   WB Analytics — Remote Deployment")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    # Connect
    print("\n🔌 Connecting to server...")
    client = create_ssh_client()
    print("  ✅ Connected!")
    
    try:
        # Check Docker
        print("\n🐳 Checking Docker...")
        run_cmd(client, 'docker --version', check=False)
        run_cmd(client, 'docker compose version 2>/dev/null || docker-compose --version 2>/dev/null', check=False)
        
        # Create directory structure
        print("\n📁 Setting up directories...")
        run_cmd(client, f'mkdir -p {REMOTE_DIR}/upload {REMOTE_DIR}/db')
        
        # Create archive
        archive_path = create_archive()
        
        # Upload archive
        print("\n📤 Uploading project archive...")
        remote_archive = f'/tmp/wb-analytics-deploy.tar.gz'
        upload_file(client, archive_path, remote_archive)
        print("  ✅ Archive uploaded!")
        
        # Extract archive
        print("\n📂 Extracting archive on server...")
        run_cmd(client, f'cd {REMOTE_DIR} && tar xzf {remote_archive}')
        run_cmd(client, f'rm {remote_archive}')
        print("  ✅ Archive extracted!")
        
        # Create Dockerfile (use SQLite instead of PostgreSQL)
        print("\n📝 Creating Dockerfile...")
        dockerfile = '''FROM node:20-alpine AS base

FROM base AS deps
WORKDIR /app
COPY package.json ./
RUN npm install

FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npx prisma generate
RUN npm run build

FROM base AS runner
WORKDIR /app
ENV NODE_ENV=production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/prisma ./prisma
COPY --from=builder /app/scripts ./scripts
COPY --from=builder /app/upload ./upload
COPY --from=builder /app/db ./db
COPY --from=builder /app/node_modules/.prisma ./node_modules/.prisma

RUN chown -R nextjs:nodejs /app/db

USER nextjs

EXPOSE 3000
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"
ENV DATABASE_URL=file:/app/db/custom.db

CMD ["node", "server.js"]
'''
        # Write Dockerfile via SFTP
        sftp = client.open_sftp()
        with sftp.open(f'{REMOTE_DIR}/Dockerfile', 'w') as f:
            f.write(dockerfile)
        sftp.close()
        print("  ✅ Dockerfile created!")
        
        # Create docker-compose.yml (use SQLite, no external network)
        print("\n📝 Creating docker-compose.yml...")
        compose = '''version: '3.8'

services:
  wb-app:
    build: .
    container_name: wb-analytics
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=file:/app/db/custom.db
      - NEXT_TELEMETRY_DISABLED=1
    volumes:
      - ./upload:/app/upload
      - ./db:/app/db
'''
        sftp = client.open_sftp()
        with sftp.open(f'{REMOTE_DIR}/docker-compose.yml', 'w') as f:
            f.write(compose)
        sftp.close()
        print("  ✅ docker-compose.yml created!")
        
        # Create .dockerignore
        print("\n📝 Creating .dockerignore...")
        dockerignore = '''node_modules
.next
.git
*.md
dev.log
'''
        sftp = client.open_sftp()
        with sftp.open(f'{REMOTE_DIR}/.dockerignore', 'w') as f:
            f.write(dockerignore)
        sftp.close()
        
        # Update next.config.ts for standalone output
        print("\n📝 Checking next.config.ts...")
        run_cmd(client, f'cat {REMOTE_DIR}/next.config.ts')
        
        # Build Docker image
        print("\n🏗️ Building Docker image (this may take a few minutes)...")
        run_cmd(client, f'cd {REMOTE_DIR} && docker compose build --no-cache 2>&1', check=False, timeout=600)
        
        # Stop old container
        print("\n🛑 Stopping old container...")
        run_cmd(client, f'cd {REMOTE_DIR} && docker compose down 2>/dev/null', check=False)
        
        # Start new container
        print("\n🚀 Starting application...")
        run_cmd(client, f'cd {REMOTE_DIR} && docker compose up -d')
        
        # Wait and check
        print("\n⏳ Waiting for application to start...")
        import time
        time.sleep(5)
        
        run_cmd(client, 'docker ps --filter name=wb-analytics --format "{{.Names}} {{.Status}}"', check=False)
        
        print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("   ✅ Deployment complete!")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"\n   Application: http://{HOST}:3000")
        print(f"   To view logs: ssh {USER}@{HOST} 'docker logs -f wb-analytics'")
        print("")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        client.close()

if __name__ == '__main__':
    main()
